package com.sai.spring.springcore.practice;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ct = new ClassPathXmlApplicationContext(
				"com/sai/spring/springcore/practice/config.xml");
		Practice p = (Practice) ct.getBean("pra");
		
		Practice p1 = (Practice) ct.getBean("pra");
		System.out.println(p.toString());
		System.out.println(p1.toString());

		//ct.registerShutdownHook();
	}

}
