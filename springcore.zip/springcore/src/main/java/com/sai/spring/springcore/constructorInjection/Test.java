package com.sai.spring.springcore.constructorInjection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"com/sai/spring/springcore/constructorInjection/config.xml");
		Employee p = (Employee) ctx.getBean("emp");
		
		System.out.println(p.toString());
		
	}

}
