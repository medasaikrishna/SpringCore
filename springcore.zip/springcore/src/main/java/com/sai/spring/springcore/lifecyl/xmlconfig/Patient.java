package com.sai.spring.springcore.lifecyl.xmlconfig;

public class Patient {
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	public void hi()
	{
		System.out.println("hiii");
	}
	
	public void bye()
	{
		System.out.println("byee");
	}
}
