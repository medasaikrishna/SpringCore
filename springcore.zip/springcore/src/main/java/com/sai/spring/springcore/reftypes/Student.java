package com.sai.spring.springcore.reftypes;

public class Student {

	private Scores scores;

	public Scores getScores() {
		return scores;
	}

	public void setScores(Scores scores) {
		this.scores = scores;
	}
}
