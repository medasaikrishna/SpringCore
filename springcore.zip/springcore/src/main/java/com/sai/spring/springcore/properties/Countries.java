package com.sai.spring.springcore.properties;

import java.util.Properties;

public class Countries {

	private Properties countryandlang;

	@Override
	public String toString() {
		return "Countries [countryandlang=" + countryandlang + "]";
	}

	public Properties getCountryandlang() {
		return countryandlang;
	}

	public void setCountryandlang(Properties countryandlang) {
		this.countryandlang = countryandlang;
	}
}
