package com.sai.spring.springcore.dependencycheck;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"com/sai/spring/springcore/dependencycheck/config.xml");
		Prescription p = (Prescription) ctx.getBean("pre");
		System.out.println(p);

	}

}
