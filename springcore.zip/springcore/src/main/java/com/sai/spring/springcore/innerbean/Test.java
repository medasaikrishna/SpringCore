package com.sai.spring.springcore.innerbean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ApplicationContext ctx = new ClassPathXmlApplicationContext(
				"com/sai/spring/springcore/innerbean/config.xml");
		Employee p = (Employee) ctx.getBean("emp");
		Employee p1 = (Employee) ctx.getBean("emp");
		System.out.println(p.toString());
		System.out.println(p1.toString());
	}

}
