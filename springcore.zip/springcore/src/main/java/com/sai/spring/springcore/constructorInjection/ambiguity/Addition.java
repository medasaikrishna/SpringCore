package com.sai.spring.springcore.constructorInjection.ambiguity;

public class Addition {
	Addition(int a, int b) {
		System.out.println("1");
	}

	Addition(double a, double b) {
		System.out.println("2");
	}

}
