package com.sai.spring.springcore.properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/sai/spring/springcore/properties/config.xml");
		Countries h = (Countries) ctx.getBean("cont");
		System.out.println(h.toString());
		
	}

}
