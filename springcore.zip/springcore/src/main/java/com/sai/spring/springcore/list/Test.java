package com.sai.spring.springcore.list;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/sai/spring/springcore/list/listconfig.xml");
		Hospital h = (Hospital) ctx.getBean("hospital");
		System.out.println(h.getName());
		System.out.println(h.getDepartments());
		System.out.println(h.getDepartments().getClass());
	}

}
