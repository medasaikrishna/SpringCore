package com.sai.spring.springcore.practice;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;

public class Practice implements InitializingBean, DisposableBean {
	private int id;
	private String name;
	
	
	private List<String> l;
	private Map<String, String> m;
	private Properties pro;

	@Autowired
	@Qualifier("pra123")
	private Practice2 practice2;
	


//	public Practice2 getPractice2() {
//		return practice2;
//	}
//
//	public void setPractice2(Practice2 practice2) {
//		this.practice2 = practice2;
//	}

	public List<String> getL() {
		return l;
	}

	@Required
	public void setL(List<String> l) {
		this.l = l;
	}

	public Map<String, String> getM() {
		return m;
	}

	public void setM(Map<String, String> m) {
		this.m = m;
	}

	public Properties getPro() {
		return pro;
	}

	public void setPro(Properties pro) {
		this.pro = pro;
	}

	@Override
	public String toString() {
		return "Practice [id=" + id + ", name=" + name + ", l=" + l + ", m=" + m + ", pro=" + pro + ", practice2="
				+ practice2 + "]";
	}

	public Practice(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

//	@PostConstruct
//	public void hi() {
//		System.out.println("hiiiii");
//	}
//	@PreDestroy
//	public void bye() {
//		System.out.println("byee");
//	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("hiii");
	}

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("byeee");
	}

}
